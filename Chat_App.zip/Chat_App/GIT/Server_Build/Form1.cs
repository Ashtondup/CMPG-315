﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Server_Build
{
    public partial class Form1 : Form
    {
        private Dictionary<string, TcpClient> connectedClients = new Dictionary<string, TcpClient>();
        private Dictionary<string, string> clientUsernames = new Dictionary<string, string>();
        private CancellationTokenSource cancellationTokenSource;
        private Dictionary<string, List<string>> groups = new Dictionary<string, List<string>>();
        private Dictionary<string, ClientHandler> clients = new Dictionary<string, ClientHandler>();
        public List<TcpClient> ActiveClients { get; private set; } = new List<TcpClient>();
        public Form1()
        {
            InitializeComponent();
        }
        
        TcpClient Client;
        TcpListener Server;
        NetworkStream Stream;
        int port = 6969;
        bool ServerStatus = false;
        private bool isServerRunning = false;
        private int clientCount = 0; // Add this at the class level
        private string serverIpAddress;

        public class ClientHandler
        {
            public TcpClient Client { get; private set; }
            public NetworkStream Stream { get; private set; }

            public ClientHandler(TcpClient client)
            {
                Client = client;
                Stream = client.GetStream();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (ServerStatus == false)
            {
                lbl_server_status.Text = "Server Status:  Offline";
            }
            else
            {
                lbl_server_status.Text = "Server Status:  Online";
            }
            lbl_clients.Text += "Clients : 0";
            GetServerIpAddress();
            lbl_server_ip.Text += serverIpAddress;
            lbl_server_port.Text += port.ToString();
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            CloseConnection();
        }
        private void GetServerIpAddress()
        {
            string hostName = Dns.GetHostName();
            IPHostEntry hostEntry = Dns.GetHostEntry(hostName);
            IPAddress ipAddress = hostEntry.AddressList.FirstOrDefault(a => a.AddressFamily == AddressFamily.InterNetwork);
            serverIpAddress = ipAddress?.ToString() ?? string.Empty;
        }


        private async void btn_Start_Server_Click(object sender, EventArgs e)
        {
            ServerStatus = true;
            Server = new TcpListener(IPAddress.Any, port);
            Server.Start();

            ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Waiting for a client to connect..." + Environment.NewLine));

            isServerRunning = true;

            if (ServerStatus == false)
            {
                lbl_server_status.Text = "Server Status:  Offline";
            }
            else
            {
                lbl_server_status.Text = "Server Status:  Online";
            }

            cancellationTokenSource = new CancellationTokenSource();

            Task.Run(async () =>
            {
                while (isServerRunning)
                {
                    try
                    {
                        TcpClient newClient = await Server.AcceptTcpClientAsync();
                        ClientHandler clientHandler = new ClientHandler(newClient);
                        HandleClient(clientHandler);
                    }
                    catch (Exception ex)
                    {
                        if (isServerRunning)
                        {
                            ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error accepting client: " + ex.Message + Environment.NewLine));
                        }
                    }
                }
            }, cancellationTokenSource.Token);
        }

        private void onConnect(IAsyncResult AR)
        {
            Client = Server.EndAcceptTcpClient(AR);
            Stream = Client.GetStream();
            byte[] buffer = new byte[1024];
            Stream.BeginRead(buffer, 0, buffer.Length, new AsyncCallback(onReceive), buffer);
            ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Connected to client" + Environment.NewLine));

            // Display a message box to indicate that a client has connected
            MessageBox.Show("A client has connected to the server.");

            // Listen for incoming data from the client
            while (true)
            {
                try
                {
                    buffer = new byte[1024];
                    int bytesRead = Stream.Read(buffer, 0, buffer.Length);
                    ControlInvoke(rch_text_log, () => rch_text_log.AppendText(">>: " + Encoding.UTF8.GetString(buffer, 0, bytesRead) + Environment.NewLine));
                }
                catch (Exception ex)
                {
                    ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error receiving data: " + ex.Message + Environment.NewLine));
                    break;
                }
            }
        }
        private void onReceive(IAsyncResult AR)
        {
            try
            {
                int bytesRead = Stream.EndRead(AR);
                if (bytesRead > 0)
                {
                    byte[] buffer = (byte[])AR.AsyncState;
                    ControlInvoke(rch_text_log, () => rch_text_log.AppendText(DateTime.Now.ToString("HH:mm:ss") + " " + ((IPEndPoint)Client.Client.RemoteEndPoint).ToString() + " (To Server): " + Encoding.UTF8.GetString(buffer, 0, bytesRead) + Environment.NewLine));
                    Stream.BeginRead(buffer, 0, buffer.Length, new AsyncCallback(onReceive), buffer);
                }
            }
            catch (Exception ex)
            {
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error receiving data: " + ex.Message + Environment.NewLine));
            }

        }

        private async void btn_server_sendmessage_Click(object sender, EventArgs e)
        {
            if (comboBoxClients.SelectedItem == null)
            {
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText("No client selected" + Environment.NewLine));
                return;
            }

            string selectedClientKey = comboBoxClients.SelectedItem.ToString();
            if (!clients.ContainsKey(selectedClientKey))
            {
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Selected client not found" + Environment.NewLine));
                return;
            }

            ClientHandler selectedClient = clients[selectedClientKey];
            NetworkStream selectedClientStream = selectedClient.Stream;

            try
            {
                byte[] message = Encoding.UTF8.GetBytes(txt_message.Text);
                await selectedClientStream.WriteAsync(message, 0, message.Length);
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " Server (To " + selectedClientKey + "): " + txt_message.Text + Environment.NewLine));

                txt_message.Clear();
            }
            catch (Exception ex)
            {
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error sending data: " + ex.Message + Environment.NewLine));
            }
        }
        delegate void UniversalVoidDelegate();

        public static void ControlInvoke(Control control, Action function)
        {

            if (control.IsDisposed || control.Disposing)
            {
                return;
            }
            if (control.InvokeRequired)
            {
                control.Invoke(new UniversalVoidDelegate(() => ControlInvoke(control, function)));
                return;
            }
            function();
        }
        private void CloseConnection()
        {
            if (Client != null && Client.Connected)
            {
                Stream.Close();
                Client.Close();
            }

            if (Server != null)
            {
                Server.Stop();
            }
        }
        private void BroadcastConnectedClients()
        {
            string clientListMessage = "ConnectedClients:";
            foreach (string clientEndpoint in connectedClients.Keys)
            {
                clientListMessage += clientEndpoint + ",";
            }

            byte[] messageBytes = Encoding.UTF8.GetBytes(clientListMessage);
            foreach (TcpClient client in connectedClients.Values)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    stream.Write(messageBytes, 0, messageBytes.Length);
                }
                catch (Exception ex)
                {
                    // Handle error if necessary
                    // This could happen if a client has disconnected unexpectedly
                    ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error sending message to client: " + ex.Message + Environment.NewLine));
                }
            }
        }
        private void btn_stop_server_Click(object sender, EventArgs e)
        {
            cancellationTokenSource.Cancel(); // This line cancels the ongoing AcceptTcpClientAsync() operation
            Server.Stop();
            btn_Start_Server.Enabled = true;
            btn_stop_server.Enabled = false;

            ServerStatus = false;
            try
            {
                isServerRunning = false;

                if (Server != null)
                {
                    Server.Stop();
                    ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Server stopped." + Environment.NewLine));
                    if (ServerStatus == false)
                    {
                        lbl_clients.Text = "Clients : 0";
                        lbl_server_status.Text = "Server Status:  Offline";
                    }
                }

                if (Stream != null)
                {
                    Stream.Close();
                }

                if (Client != null)
                {
                    Client.Close();
                }
            }
            catch (Exception ex)
            {
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error stopping server: " + ex.Message + Environment.NewLine));
            }
        }
        private void BroadcastConnectedUsernames()
        {
            List<string> usernames = clientUsernames.Values.ToList();
            string usernameListMessage = string.Join(",", usernames);

            byte[] messageBytes = Encoding.UTF8.GetBytes(usernameListMessage);

            foreach (TcpClient client in connectedClients.Values)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    stream.Write(messageBytes, 0, messageBytes.Length);
                }
                catch (Exception ex)
                {
                    ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error sending username list to client: " + ex.Message + Environment.NewLine));
                }
            }
        }
        private async void HandleClient(ClientHandler clientHandler)
        {
            string clientEndpoint = clientHandler.Client.Client.RemoteEndPoint.ToString();

            // Receive the username from the client
            byte[] usernameBuffer = new byte[1024];
            int usernameBytesRead = await clientHandler.Stream.ReadAsync(usernameBuffer, 0, usernameBuffer.Length);
            string username = Encoding.UTF8.GetString(usernameBuffer, 0, usernameBytesRead);

            // Store the username in the dictionary
            clientUsernames[clientEndpoint] = username;

            // Broadcast the updated list of usernames to all clients
            BroadcastConnectedUsernames();

            try
            {
                NetworkStream streamHandler = clientHandler.Stream;
                byte[] buffer = new byte[1024];

                while (true)
                {
                    int bytesRead = await streamHandler.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead == 0)
                    {
                        // Client disconnected
                        break;
                    }
                    string receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    // Check if the received message is a group chat message
                    if (receivedMessage.Contains("ToGroup:"))
                    {
                        string[] messageParts = receivedMessage.Substring("ToGroup:".Length).Split(new[] { "Group:", "Message:" }, StringSplitOptions.RemoveEmptyEntries);
                        if (messageParts.Length == 3)
                        {
                            string sender = clientEndpoint;
                            string groupName = messageParts[0].Trim();
                            string messageContent = messageParts[1].Trim();

                            // Handle the group chat message
                            await HandleGroupChatMessage(sender, groupName, messageContent);
                        }
                    }
                    else
                    {
                        // Parse the received message
                        var messageParts = receivedMessage.Split(new[] { "To:", "Message:" }, StringSplitOptions.RemoveEmptyEntries);
                        if (messageParts.Length == 2)
                        {
                            string recipient = messageParts[0].Trim();
                            string message = messageParts[1].Trim();

                            if (clients.ContainsKey(recipient))
                            {
                                // Forward the message to the recipient
                                byte[] messageToForward = Encoding.UTF8.GetBytes("From:" + clientEndpoint + " Message:" + message);
                                await clients[recipient].Stream.WriteAsync(messageToForward, 0, messageToForward.Length);
                            }
                        }

                        ControlInvoke(rch_text_log, () => rch_text_log.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + clientEndpoint + " (To Server): " + receivedMessage + Environment.NewLine));
                    }
                }
            }
            catch (Exception ex)
            {
                // Log the error or display a message
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error: " + ex.Message + Environment.NewLine));
            }
            finally
            {
                // Remove the client from the comboBoxClients and close the connection
                ControlInvoke(comboBoxClients, () => comboBoxClients.Items.Remove(clientEndpoint));
                clientHandler.Client.Close();
                lock (connectedClients)
                {
                    connectedClients.Remove(clientEndpoint);
                    clients.Remove(clientEndpoint);
                    clientCount--; // Decrement the counter
                }
                ControlInvoke(lbl_clients, () => lbl_clients.Text = $"Clients: {clientCount}"); // Update the label
                BroadcastConnectedClients();
                BroadcastConnectedUsernames();
            }
        }
        private async Task HandleGroupChatMessage(string sender, string groupName, string messageContent)
        {
            if (groups.ContainsKey(groupName))
            {
                List<string> groupMembers = groups[groupName];

                // Prepare the group chat message to send to all members
                string groupChatMessage = $"From:[GroupChat]{groupName} Message:{messageContent}";

                // Send the group chat message to all group members
                foreach (string member in groupMembers)
                {
                    if (member != sender && clients.ContainsKey(member))
                    {
                        try
                        {
                            byte[] messageBytes = Encoding.UTF8.GetBytes(groupChatMessage);
                            await clients[member].Stream.WriteAsync(messageBytes, 0, messageBytes.Length);
                        }
                        catch (Exception ex)
                        {
                            ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Error sending group chat message: " + ex.Message + Environment.NewLine));
                        }
                    }
                }

                // Log the group chat message
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + " " + sender + " (To Group " + groupName + "): " + messageContent + Environment.NewLine));
            }
            else
            {
                ControlInvoke(rch_text_log, () => rch_text_log.AppendText("Group name does not exist." + Environment.NewLine));
            }
        }

        private void AddClientToGroup(string groupName, string ipAddress)
        {
            if (groups.ContainsKey(groupName))
            {
                if (!groups[groupName].Contains(ipAddress))
                {
                    groups[groupName].Add(ipAddress);
                }
            }
            else
            {
                groups[groupName] = new List<string> { ipAddress };
            }
        }

        // Method to remove a client from a group
        private void RemoveClientFromGroup(string groupName, string ipAddress)
        {
            if (groups.ContainsKey(groupName))
            {
                groups[groupName].Remove(ipAddress);
                if (groups[groupName].Count == 0)
                {
                    groups.Remove(groupName);
                }
            }
        }

        // Method to send a group message
        private async Task SendGroupMessage(string groupName, string message)
        {
            if (groups.ContainsKey(groupName))
            {
                List<string> groupMembers = groups[groupName];
                byte[] messageBytes = Encoding.UTF8.GetBytes("From:[GroupChat]" + groupName + " Message:" + message);

                foreach (string ipAddress in groupMembers)
                {
                    if (connectedClients.ContainsKey(ipAddress))
                    {
                        TcpClient client = connectedClients[ipAddress];
                        NetworkStream stream = client.GetStream();
                        await stream.WriteAsync(messageBytes, 0, messageBytes.Length);
                    }
                }
            }
        }

    }

    public static class TaskExtensions
    {
        public static async Task WithCancellation(this Task task, CancellationToken cancellationToken)
        {
            var tcs = new TaskCompletionSource<bool>();
            using (cancellationToken.Register(s => ((TaskCompletionSource<bool>)s).TrySetResult(true), tcs))
                if (task != await Task.WhenAny(task, tcs.Task))
                    throw new OperationCanceledException(cancellationToken);
        }
    }
}