﻿namespace Client_Build
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.rch_txt_messages = new System.Windows.Forms.RichTextBox();
            this.btn_connect_to_server = new System.Windows.Forms.Button();
            this.btn_send_message = new System.Windows.Forms.Button();
            this.txt_message = new System.Windows.Forms.TextBox();
            this.comboBoxClientsOnline = new System.Windows.Forms.ComboBox();
            this.lbl_view_clients = new System.Windows.Forms.Label();
            this.btn_disconnect = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.rch_groupchat = new System.Windows.Forms.RichTextBox();
            this.btn_group_message_send = new System.Windows.Forms.Button();
            this.btn_view_members = new System.Windows.Forms.Button();
            this.btn_add_members = new System.Windows.Forms.Button();
            this.btn_create_group = new System.Windows.Forms.Button();
            this.cbx_groups = new System.Windows.Forms.ComboBox();
            this.rch_members = new System.Windows.Forms.RichTextBox();
            this.checkedListBox = new System.Windows.Forms.CheckedListBox();
            this.txt_groupname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbx_group_availible = new System.Windows.Forms.ComboBox();
            this.txt_group_message = new System.Windows.Forms.TextBox();
            this.txt_username = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 35.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 59);
            this.label1.TabIndex = 0;
            this.label1.Text = "Client";
            // 
            // rch_txt_messages
            // 
            this.rch_txt_messages.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rch_txt_messages.Location = new System.Drawing.Point(18, 36);
            this.rch_txt_messages.Name = "rch_txt_messages";
            this.rch_txt_messages.Size = new System.Drawing.Size(681, 345);
            this.rch_txt_messages.TabIndex = 1;
            this.rch_txt_messages.Text = "";
            // 
            // btn_connect_to_server
            // 
            this.btn_connect_to_server.BackColor = System.Drawing.Color.LightGray;
            this.btn_connect_to_server.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_connect_to_server.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_connect_to_server.ForeColor = System.Drawing.Color.Black;
            this.btn_connect_to_server.Location = new System.Drawing.Point(32, 69);
            this.btn_connect_to_server.Name = "btn_connect_to_server";
            this.btn_connect_to_server.Size = new System.Drawing.Size(121, 35);
            this.btn_connect_to_server.TabIndex = 2;
            this.btn_connect_to_server.Text = "Connect";
            this.btn_connect_to_server.UseVisualStyleBackColor = false;
            this.btn_connect_to_server.Click += new System.EventHandler(this.btn_connect_to_server_Click);
            // 
            // btn_send_message
            // 
            this.btn_send_message.BackColor = System.Drawing.Color.LightGray;
            this.btn_send_message.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_send_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_send_message.ForeColor = System.Drawing.Color.Black;
            this.btn_send_message.Location = new System.Drawing.Point(533, 399);
            this.btn_send_message.Name = "btn_send_message";
            this.btn_send_message.Size = new System.Drawing.Size(133, 42);
            this.btn_send_message.TabIndex = 3;
            this.btn_send_message.Text = "Send Message";
            this.btn_send_message.UseVisualStyleBackColor = false;
            this.btn_send_message.Click += new System.EventHandler(this.btn_send_message_Click);
            // 
            // txt_message
            // 
            this.txt_message.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_message.Location = new System.Drawing.Point(167, 409);
            this.txt_message.Name = "txt_message";
            this.txt_message.Size = new System.Drawing.Size(277, 23);
            this.txt_message.TabIndex = 4;
            // 
            // comboBoxClientsOnline
            // 
            this.comboBoxClientsOnline.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxClientsOnline.FormattingEnabled = true;
            this.comboBoxClientsOnline.Location = new System.Drawing.Point(18, 6);
            this.comboBoxClientsOnline.Name = "comboBoxClientsOnline";
            this.comboBoxClientsOnline.Size = new System.Drawing.Size(382, 24);
            this.comboBoxClientsOnline.TabIndex = 5;
            // 
            // lbl_view_clients
            // 
            this.lbl_view_clients.AutoSize = true;
            this.lbl_view_clients.BackColor = System.Drawing.Color.Transparent;
            this.lbl_view_clients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_view_clients.Location = new System.Drawing.Point(585, 9);
            this.lbl_view_clients.Name = "lbl_view_clients";
            this.lbl_view_clients.Size = new System.Drawing.Size(114, 17);
            this.lbl_view_clients.TabIndex = 6;
            this.lbl_view_clients.Text = "Clients Online:";
            // 
            // btn_disconnect
            // 
            this.btn_disconnect.BackColor = System.Drawing.Color.LightGray;
            this.btn_disconnect.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_disconnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_disconnect.ForeColor = System.Drawing.Color.Black;
            this.btn_disconnect.Location = new System.Drawing.Point(193, 69);
            this.btn_disconnect.Name = "btn_disconnect";
            this.btn_disconnect.Size = new System.Drawing.Size(119, 35);
            this.btn_disconnect.TabIndex = 7;
            this.btn_disconnect.Text = "Disconnect";
            this.btn_disconnect.UseVisualStyleBackColor = false;
            this.btn_disconnect.Click += new System.EventHandler(this.btn_disconnect_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(40, 412);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Enter message:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(32, 110);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(725, 506);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lbl_view_clients);
            this.tabPage1.Controls.Add(this.comboBoxClientsOnline);
            this.tabPage1.Controls.Add(this.rch_txt_messages);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.btn_send_message);
            this.tabPage1.Controls.Add(this.txt_message);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(717, 480);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Private Chat";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.rch_groupchat);
            this.tabPage2.Controls.Add(this.btn_group_message_send);
            this.tabPage2.Controls.Add(this.btn_view_members);
            this.tabPage2.Controls.Add(this.btn_add_members);
            this.tabPage2.Controls.Add(this.btn_create_group);
            this.tabPage2.Controls.Add(this.cbx_groups);
            this.tabPage2.Controls.Add(this.rch_members);
            this.tabPage2.Controls.Add(this.checkedListBox);
            this.tabPage2.Controls.Add(this.txt_groupname);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.cbx_group_availible);
            this.tabPage2.Controls.Add(this.txt_group_message);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(717, 480);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Group Chat";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // rch_groupchat
            // 
            this.rch_groupchat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rch_groupchat.Location = new System.Drawing.Point(18, 11);
            this.rch_groupchat.Name = "rch_groupchat";
            this.rch_groupchat.Size = new System.Drawing.Size(356, 402);
            this.rch_groupchat.TabIndex = 38;
            this.rch_groupchat.Text = "";
            // 
            // btn_group_message_send
            // 
            this.btn_group_message_send.BackColor = System.Drawing.Color.LightGray;
            this.btn_group_message_send.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_group_message_send.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_group_message_send.ForeColor = System.Drawing.Color.Black;
            this.btn_group_message_send.Location = new System.Drawing.Point(253, 445);
            this.btn_group_message_send.Name = "btn_group_message_send";
            this.btn_group_message_send.Size = new System.Drawing.Size(121, 35);
            this.btn_group_message_send.TabIndex = 37;
            this.btn_group_message_send.Text = "Send Group";
            this.btn_group_message_send.UseVisualStyleBackColor = false;
            // 
            // btn_view_members
            // 
            this.btn_view_members.BackColor = System.Drawing.Color.LightGray;
            this.btn_view_members.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_view_members.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_view_members.ForeColor = System.Drawing.Color.Black;
            this.btn_view_members.Location = new System.Drawing.Point(476, 445);
            this.btn_view_members.Name = "btn_view_members";
            this.btn_view_members.Size = new System.Drawing.Size(121, 35);
            this.btn_view_members.TabIndex = 36;
            this.btn_view_members.Text = "View Members";
            this.btn_view_members.UseVisualStyleBackColor = false;
            // 
            // btn_add_members
            // 
            this.btn_add_members.BackColor = System.Drawing.Color.LightGray;
            this.btn_add_members.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_add_members.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_members.ForeColor = System.Drawing.Color.Black;
            this.btn_add_members.Location = new System.Drawing.Point(476, 306);
            this.btn_add_members.Name = "btn_add_members";
            this.btn_add_members.Size = new System.Drawing.Size(121, 35);
            this.btn_add_members.TabIndex = 35;
            this.btn_add_members.Text = "Add Member";
            this.btn_add_members.UseVisualStyleBackColor = false;
            // 
            // btn_create_group
            // 
            this.btn_create_group.BackColor = System.Drawing.Color.LightGray;
            this.btn_create_group.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_create_group.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_create_group.ForeColor = System.Drawing.Color.Black;
            this.btn_create_group.Location = new System.Drawing.Point(476, 37);
            this.btn_create_group.Name = "btn_create_group";
            this.btn_create_group.Size = new System.Drawing.Size(121, 35);
            this.btn_create_group.TabIndex = 10;
            this.btn_create_group.Text = "Create Group";
            this.btn_create_group.UseVisualStyleBackColor = false;
            // 
            // cbx_groups
            // 
            this.cbx_groups.FormattingEnabled = true;
            this.cbx_groups.Location = new System.Drawing.Point(34, 418);
            this.cbx_groups.Name = "cbx_groups";
            this.cbx_groups.Size = new System.Drawing.Size(284, 21);
            this.cbx_groups.TabIndex = 34;
            // 
            // rch_members
            // 
            this.rch_members.Location = new System.Drawing.Point(396, 347);
            this.rch_members.Name = "rch_members";
            this.rch_members.Size = new System.Drawing.Size(266, 96);
            this.rch_members.TabIndex = 33;
            this.rch_members.Text = "";
            // 
            // checkedListBox
            // 
            this.checkedListBox.FormattingEnabled = true;
            this.checkedListBox.Location = new System.Drawing.Point(396, 116);
            this.checkedListBox.Name = "checkedListBox";
            this.checkedListBox.Size = new System.Drawing.Size(266, 184);
            this.checkedListBox.TabIndex = 31;
            // 
            // txt_groupname
            // 
            this.txt_groupname.Location = new System.Drawing.Point(541, 11);
            this.txt_groupname.Name = "txt_groupname";
            this.txt_groupname.Size = new System.Drawing.Size(121, 20);
            this.txt_groupname.TabIndex = 29;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(408, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 17);
            this.label5.TabIndex = 27;
            this.label5.Text = "Group name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(408, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 17);
            this.label4.TabIndex = 26;
            this.label4.Text = "Groups Availible";
            // 
            // cbx_group_availible
            // 
            this.cbx_group_availible.FormattingEnabled = true;
            this.cbx_group_availible.Location = new System.Drawing.Point(541, 89);
            this.cbx_group_availible.Name = "cbx_group_availible";
            this.cbx_group_availible.Size = new System.Drawing.Size(121, 21);
            this.cbx_group_availible.TabIndex = 25;
            // 
            // txt_group_message
            // 
            this.txt_group_message.Location = new System.Drawing.Point(6, 453);
            this.txt_group_message.Name = "txt_group_message";
            this.txt_group_message.Size = new System.Drawing.Size(241, 20);
            this.txt_group_message.TabIndex = 24;
            // 
            // txt_username
            // 
            this.txt_username.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_username.Location = new System.Drawing.Point(596, 75);
            this.txt_username.Name = "txt_username";
            this.txt_username.Size = new System.Drawing.Size(157, 23);
            this.txt_username.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(509, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 17);
            this.label3.TabIndex = 9;
            this.label3.Text = "Username";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.LightGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(357, 69);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 35);
            this.button1.TabIndex = 10;
            this.button1.Text = "Quit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Client_Build.Properties.Resources.network;
            this.ClientSize = new System.Drawing.Size(794, 652);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_username);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btn_disconnect);
            this.Controls.Add(this.btn_connect_to_server);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox rch_txt_messages;
        private System.Windows.Forms.Button btn_connect_to_server;
        private System.Windows.Forms.Button btn_send_message;
        private System.Windows.Forms.TextBox txt_message;
        private System.Windows.Forms.ComboBox comboBoxClientsOnline;
        private System.Windows.Forms.Label lbl_view_clients;
        private System.Windows.Forms.Button btn_disconnect;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RichTextBox rch_groupchat;
        private System.Windows.Forms.Button btn_group_message_send;
        private System.Windows.Forms.Button btn_view_members;
        private System.Windows.Forms.Button btn_add_members;
        private System.Windows.Forms.Button btn_create_group;
        private System.Windows.Forms.ComboBox cbx_groups;
        private System.Windows.Forms.RichTextBox rch_members;
        private System.Windows.Forms.CheckedListBox checkedListBox;
        private System.Windows.Forms.TextBox txt_groupname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbx_group_availible;
        private System.Windows.Forms.TextBox txt_group_message;
        private System.Windows.Forms.TextBox txt_username;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}

