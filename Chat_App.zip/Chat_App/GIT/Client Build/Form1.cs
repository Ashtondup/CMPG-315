﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using Microsoft.VisualBasic;

namespace Client_Build
{
    public partial class Form1 : Form
    {
        private Dictionary<string, List<string>> groupsDictionary;
        private Dictionary<string, NetworkStream> groupChatStreams = new Dictionary<string, NetworkStream>();
        private readonly string IP_ADDRESS = "ec2-16-16-74-119.eu-north-1.compute.amazonaws.com"; // Change this to the IP address of the server
        private readonly int PORT = 6969; // Change this to the port of the server
        private TcpClient client;
        private NetworkStream stream;
        private string username;
        private Thread receiveThread;
        private bool receiving;
        private bool groupdate;
        private Thread groupChatThread;
        private bool receivingGroupChat;

        public Form1()
        {
            InitializeComponent();
            receiving = false;
            groupsDictionary = new Dictionary<string, List<string>>();

        }
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                // Trigger the button's click event
                btn_send_message.PerformClick();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            btn_connect_to_server.Enabled = true;
            btn_disconnect.Enabled = false;
            rch_txt_messages.SelectionAlignment = HorizontalAlignment.Center; // Align text to the center
            rch_txt_messages.AppendText(DateTime.Now.ToString("yyyy-MM-dd" + Environment.NewLine));
            Application.ApplicationExit += Application_ApplicationExit;
            this.KeyPress += Form1_KeyPress;
        }
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Check if the tab containing the CheckedListBox is selected
            if (tabControl1.SelectedTab == tabPage2)
            {
                cbx_group_availible.Enabled = false;
                checkedListBox.Enabled = false;

            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (client != null && client.Connected)
                {
                    string disconnectMessage = "Forcefully Disconnected";
                    byte[] messageBytes = Encoding.UTF8.GetBytes(disconnectMessage);
                    stream.WriteAsync(messageBytes, 0, messageBytes.Length);
                    client.Close();
                    CloseConnection();
                }
            }
        }
        private void Application_ApplicationExit(object sender, EventArgs e)
        {
            if (client != null && client.Connected)
            {
                string disconnectMessage = "Forcefully Disconnected";
                byte[] messageBytes = Encoding.UTF8.GetBytes(disconnectMessage);
                stream.WriteAsync(messageBytes, 0, messageBytes.Length);
                client.Close();
                CloseConnection();
            }
        }
        private async void btn_send_message_Click(object sender, EventArgs e)
        {
            rch_txt_messages.SelectionAlignment = HorizontalAlignment.Left;
            if (client == null || !client.Connected)
            {
                MessageBox.Show("You are not connected to the server.");
                return;
            }
            if (string.IsNullOrEmpty(txt_message.Text))
            {
                MessageBox.Show("Please enter a message.");
                return;
            }
            if (comboBoxClientsOnline.SelectedItem == null)
            {
                MessageBox.Show("Please select a recipient.");
                return;
            }

            // Extract the IP address without the " (Yourself)" suffix
            string recipient = comboBoxClientsOnline.SelectedItem.ToString();
            if (recipient.EndsWith(" (Yourself)"))
            {
                recipient = recipient.Substring(0, recipient.Length - 10);
            }

            try
            {
                rch_txt_messages.AppendText("You : " + txt_message.Text + Environment.NewLine);
                rch_txt_messages.AppendText("Sent to : " + recipient + Environment.NewLine);
                string messageToSend = "To:" + recipient + " Message:" + txt_message.Text;
                byte[] buffer = Encoding.UTF8.GetBytes(messageToSend);
                stream.Write(buffer, 0, buffer.Length);
                txt_message.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending message: " + ex.Message);
            }
        }

        private void btn_connect_to_server_Click(object sender, EventArgs e)
        {
            try
            {
                rch_txt_messages.Clear();
                rch_txt_messages.AppendText(DateTime.Now.ToString("yyyy-MM-dd" + Environment.NewLine));
                client = new TcpClient();
                client.Connect(IP_ADDRESS, PORT);
                stream = client.GetStream();
                AddMessage("Connected to server.");

                // Send client IP address and port number to the server
                string clientInfo = String.Format("ClientInfo:{0}:{1}", ((IPEndPoint)client.Client.LocalEndPoint).Address.ToString(), ((IPEndPoint)client.Client.LocalEndPoint).Port.ToString());
                Send(clientInfo);

                // Start the receive thread
                receiving = true;
                receiveThread = new Thread(new ThreadStart(Receive));
                receiveThread.Start();
                btn_connect_to_server.Enabled = false;
                btn_disconnect.Enabled = true;
            }
            catch (SocketException)
            {
                MessageBox.Show("Could not connect to server. Please make sure the server is online.", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void Send(string message)
        {
            byte[] buffer = Encoding.UTF8.GetBytes(message);
            stream.Write(buffer, 0, buffer.Length);
        }
        private void Receive()
        {
            while (receiving)
            {
                try
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead > 0)
                    {
                        string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                        if (message.StartsWith("ConnectedClients:"))
                        {
                            string[] clients = message.Substring("ConnectedClients:".Length).Split(',');
                            UpdateConnectedClientsComboBox(clients);
                        }
                        else if (message.StartsWith("From:"))
                        {
                            string[] messageParts = message.Substring("From:".Length).Split(new[] { "Message:" }, StringSplitOptions.RemoveEmptyEntries);
                            if (messageParts.Length == 2)
                            {
                                string sender = messageParts[0].Trim();
                                string messageContent = messageParts[1].Trim();

                                ControlInvoke(rch_txt_messages, () =>
                                {
                                    rch_txt_messages.SelectionAlignment = HorizontalAlignment.Right;
                                    rch_txt_messages.AppendText("<< " + sender + " (To You): " + messageContent + Environment.NewLine);
                                });
                            }
                        }
                        else
                        {
                            ControlInvoke(rch_txt_messages, () =>
                            {
                                string senderInfo = "Received from " + ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
                                string formattedMessage = senderInfo + message;
                                if (formattedMessage.Contains("(To Server):"))
                                {
                                    rch_txt_messages.SelectionAlignment = HorizontalAlignment.Left;
                                    rch_txt_messages.AppendText(formattedMessage + Environment.NewLine);
                                }
                                else
                                {
                                    rch_txt_messages.SelectionAlignment = HorizontalAlignment.Right;
                                    rch_txt_messages.AppendText(senderInfo + Environment.NewLine);
                                    rch_txt_messages.AppendText(message + Environment.NewLine);
                                }
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Add the message box here to notify that the connection was lost
                    if (!client.Connected)
                    {
                        //MessageBox.Show("Connection lost.");
                        receiving = false;
                    }
                    else
                    {
                        ControlInvoke(rch_txt_messages, () => rch_txt_messages.AppendText("Error receiving data: " + ex.Message + Environment.NewLine));
                    }
                }
            }
        }
        private async void ReceiveGroupChatMessages(NetworkStream stream)
        {
            while (receivingGroupChat)
            {
                try
                {
                    byte[] buffer = new byte[1024];
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead > 0)
                    {
                        string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                        if (message.StartsWith("From:[GroupChat]"))
                        {
                            // Handle group chat message
                            string[] messageParts = message.Substring("From:[GroupChat]".Length).Split(new[] { "Message:" }, StringSplitOptions.RemoveEmptyEntries);
                            if (messageParts.Length == 2)
                            {
                                string groupName = messageParts[0].Trim();
                                string messageContent = messageParts[1].Trim();

                                ControlInvoke(rch_groupchat, () =>
                                {
                                    rch_groupchat.SelectionAlignment = HorizontalAlignment.Left;
                                    rch_groupchat.AppendText("<< " + groupName + ": " + messageContent + Environment.NewLine);
                                });
                            }
                        }
                        else
                        {
                            // Handle peer-to-peer chat message
                            ControlInvoke(rch_txt_messages, () =>
                            {
                                // ...
                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                    // ...
                }
            }
        }

        private void HandleGroupChatConnection(string groupName)
        {
            // Check if the group name exists in the dictionary
            if (groupsDictionary.ContainsKey(groupName))
            {
                // Get the IP addresses of group members
                List<string> groupMembers = groupsDictionary[groupName];

                foreach (string member in groupMembers)
                {
                    try
                    {
                        // Connect to each group member's IP address
                        TcpClient memberClient = new TcpClient();
                        memberClient.Connect(member, PORT);

                        // Get the network stream for the group member
                        NetworkStream stream = memberClient.GetStream();

                        // Add the stream to the group chat streams dictionary
                        groupChatStreams.Add(member, stream);

                        // Start receiving group chat messages from the member
                        ReceiveGroupChatMessages(stream);
                    }
                    catch (Exception ex)
                    {
                        // Handle connection exceptions
                        // ...
                    }
                }
            }
        }
        private void UpdateConnectedClientsComboBox(string[] clients)
        {
            ControlInvoke(comboBoxClientsOnline, () =>
            {
                comboBoxClientsOnline.Items.Clear();
                string ownIPAddress = ((IPEndPoint)client.Client.LocalEndPoint).Address.ToString();
                string ownEndpoint = ((IPEndPoint)client.Client.LocalEndPoint).ToString();

                comboBoxClientsOnline.Items.Add(ownEndpoint + " (Yourself)");

                foreach (string client in clients)
                {
                    if (!string.IsNullOrEmpty(client) && client != ownEndpoint)
                    {
                        comboBoxClientsOnline.Items.Add(client);
                    }
                }
            });
            UpdateCheckedListBox(clients);
        }
        private void UpdateCheckedListBox(string[] clients)
        {
            ControlInvoke(checkedListBox, () =>
            {
                checkedListBox.Items.Clear();

                foreach (string client in clients)
                {
                    if (!string.IsNullOrEmpty(client))
                    {
                        checkedListBox.Items.Add(client);
                    }
                }
            });
        }

        private void AddMessage(string message)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(() => AddMessage(message)));
            }
            else
            {
                rch_txt_messages.AppendText(message + Environment.NewLine);
            }
        }
        delegate void UniversalVoidDelegate();

        public static void ControlInvoke(Control control, Action function)
        {

            if (control.IsDisposed || control.Disposing)
            {
                return;
            }
            if (control.InvokeRequired)
            {
                control.Invoke(new UniversalVoidDelegate(() => ControlInvoke(control, function)));
                return;
            }
            function();
        }
        private void CloseConnection()
        {
            if (client != null && client.Connected)
            {
                receiving = false;
                receiveThread.Join();
                stream.Close();
                client.Close();
            }
        }
        private void CloseGroupChatConnections()
        {
            foreach (NetworkStream stream in groupChatStreams.Values)
            {
                stream.Close();
            }

            groupChatStreams.Clear();
        }

        private async void btn_disconnect_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    // Send a disconnect message
                    string disconnectMessage = "Disconnecting";
                    byte[] messageBytes = Encoding.UTF8.GetBytes(disconnectMessage);
                    await stream.WriteAsync(messageBytes, 0, messageBytes.Length);
                    btn_connect_to_server.Enabled = true;
                    // Close the connection
                    client.Close();
                    rch_txt_messages.Text = "You have Disconnected From the Server";
                    btn_disconnect.Enabled = false;

                }
                catch (Exception ex)
                {
                    // Handle any errors
                    MessageBox.Show("Error disconnecting: " + ex.Message);
                }
            }
        }

        private void btn_add_members_Click(object sender, EventArgs e)
        {
            // Get the selected group name
            string groupName = cbx_group_availible.SelectedItem?.ToString();

            // Check if a group is selected
            if (string.IsNullOrEmpty(groupName))
            {
                MessageBox.Show("Please select a group.");
                return;
            }

            // Check if the group name exists in the dictionary
            if (!groupsDictionary.ContainsKey(groupName))
            {
                MessageBox.Show("Group name does not exist.");
                return;
            }

            // Check if any members are selected
            if (checkedListBox.CheckedItems.Count == 0)
            {
                MessageBox.Show("No members have been selected.");
                return;
            }

            // Get the selected IP addresses
            var selectedIPAddresses = checkedListBox.CheckedItems.Cast<string>().ToList();

            // Get the existing members of the group
            List<string> existingMembers = groupsDictionary[groupName];

            // Check if any selected IP address is already a member of the group
            List<string> duplicateMembers = selectedIPAddresses.Intersect(existingMembers).ToList();
            if (duplicateMembers.Count > 0)
            {
                MessageBox.Show($"The following member(s) already exist in the group: {string.Join(", ", duplicateMembers)}");
                return;
            }

            // Add the selected IP addresses to the group's IP addresses
            List<string> ipAddresses = groupsDictionary[groupName];
            ipAddresses.AddRange(selectedIPAddresses);

            // Clear the checked items in the CheckedListBox
            checkedListBox.ClearSelected();

            // Show a success message
            MessageBox.Show("IP addresses added to the group successfully.");
        }

        private void btn_create_group_Click(object sender, EventArgs e)
        {
            if (groupdate == false)
            {
                rch_groupchat.SelectionAlignment = HorizontalAlignment.Center; // Align text to the center
                rch_groupchat.AppendText(DateTime.Now.ToString("yyyy-MM-dd" + Environment.NewLine));
            }

            groupdate = true;

            string groupName = txt_groupname.Text.Trim();

            if (string.IsNullOrEmpty(groupName))
            {
                MessageBox.Show("Please enter a group name.");
                return;
            }

            // Check if the group name already exists in the dictionary
            if (groupsDictionary.ContainsKey(groupName))
            {
                MessageBox.Show("Group name already exists.");
                return;
            }

            // Create a new list of IP addresses for the group
            List<string> ipAddresses = new List<string>();

            // Add the group name and associated IP addresses to the dictionary
            groupsDictionary.Add(groupName, ipAddresses);

            // Add the group name to the cbx_group_availible ComboBox
            cbx_group_availible.Items.Add(groupName);
            cbx_groups.Items.Add(groupName);

            // Clear the textbox for the next group name entry
            txt_groupname.Clear();
        }

        private void AddIPAddressToGroup(string groupName, string ipAddress)
        {
            // Check if the group name exists in the dictionary
            if (groupsDictionary.ContainsKey(groupName))
            {
                // Get the list of IP addresses for the group
                List<string> ipAddresses = groupsDictionary[groupName];

                // Add the new IP address to the list
                ipAddresses.Add(ipAddress);
            }
            else
            {
                MessageBox.Show("Group name does not exist.");
            }
        }


        private void btn_view_members_Click(object sender, EventArgs e)
        {
            // Get the selected group name
            string groupName = cbx_group_availible.SelectedItem?.ToString();

            // Check if a group is selected
            if (string.IsNullOrEmpty(groupName))
            {
                MessageBox.Show("Please select a group.");
                return;
            }

            // Check if the group name exists in the dictionary
            if (!groupsDictionary.ContainsKey(groupName))
            {
                MessageBox.Show("Group name does not exist.");
                return;
            }

            // Get the members of the selected group
            List<string> members = groupsDictionary[groupName];

            // Clear the RichTextBox
            rch_members.Clear();

            // Display the members in the RichTextBox
            rch_members.AppendText($"Members of {groupName}:{Environment.NewLine}");
            foreach (string member in members)
            {
                rch_members.AppendText($"{member}{Environment.NewLine}");
            }
        }

        private void btn_group_message_send_Click(object sender, EventArgs e)
        {
            string groupName = cbx_groups.SelectedItem?.ToString();

            // Check if a group is selected
            if (string.IsNullOrEmpty(groupName))
            {
                MessageBox.Show("Please select a group.");
                return;
            }

            // Check if the group name exists in the dictionary
            if (!groupsDictionary.ContainsKey(groupName))
            {
                MessageBox.Show("Group name does not exist.");
                return;
            }

            // Get the message to send
            string message = txt_group_message.Text.Trim();

            // Check if the message is empty
            if (string.IsNullOrEmpty(message))
            {
                MessageBox.Show("Please enter a message.");
                return;
            }

            // Create the group chat message in the format "[GroupChat]GroupName:MessageContent"
            string groupChatMessage = $"From:[GroupChat]{groupName} Message:{message}";

            // Send the group chat message to the server
            Send(groupChatMessage);

            // Clear the message textbox
            txt_group_message.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
