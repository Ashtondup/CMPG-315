﻿namespace Server_Build
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Start_Server = new System.Windows.Forms.Button();
            this.btn_stop_server = new System.Windows.Forms.Button();
            this.rch_text_log = new System.Windows.Forms.RichTextBox();
            this.comboBoxClients = new System.Windows.Forms.ComboBox();
            this.btn_settings = new System.Windows.Forms.Button();
            this.lbl_server_status = new System.Windows.Forms.Label();
            this.lbl_clients = new System.Windows.Forms.Label();
            this.lbl_server_ip = new System.Windows.Forms.Label();
            this.lbl_server_port = new System.Windows.Forms.Label();
            this.txt_message = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_server_sendmessage = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 34.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(42, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 67);
            this.label1.TabIndex = 0;
            this.label1.Text = "Server";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_Start_Server
            // 
            this.btn_Start_Server.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_Start_Server.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Start_Server.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Start_Server.Location = new System.Drawing.Point(52, 106);
            this.btn_Start_Server.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Start_Server.Name = "btn_Start_Server";
            this.btn_Start_Server.Size = new System.Drawing.Size(141, 51);
            this.btn_Start_Server.TabIndex = 1;
            this.btn_Start_Server.Text = "Connect";
            this.btn_Start_Server.UseVisualStyleBackColor = false;
            this.btn_Start_Server.Click += new System.EventHandler(this.btn_Start_Server_Click);
            // 
            // btn_stop_server
            // 
            this.btn_stop_server.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_stop_server.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_stop_server.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stop_server.Location = new System.Drawing.Point(235, 106);
            this.btn_stop_server.Margin = new System.Windows.Forms.Padding(4);
            this.btn_stop_server.Name = "btn_stop_server";
            this.btn_stop_server.Size = new System.Drawing.Size(128, 51);
            this.btn_stop_server.TabIndex = 2;
            this.btn_stop_server.Text = "Disconnect";
            this.btn_stop_server.UseVisualStyleBackColor = false;
            this.btn_stop_server.Click += new System.EventHandler(this.btn_stop_server_Click);
            // 
            // rch_text_log
            // 
            this.rch_text_log.Location = new System.Drawing.Point(52, 195);
            this.rch_text_log.Margin = new System.Windows.Forms.Padding(4);
            this.rch_text_log.Name = "rch_text_log";
            this.rch_text_log.Size = new System.Drawing.Size(489, 281);
            this.rch_text_log.TabIndex = 3;
            this.rch_text_log.Text = "";
            // 
            // comboBoxClients
            // 
            this.comboBoxClients.FormattingEnabled = true;
            this.comboBoxClients.Location = new System.Drawing.Point(408, 542);
            this.comboBoxClients.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxClients.Name = "comboBoxClients";
            this.comboBoxClients.Size = new System.Drawing.Size(133, 24);
            this.comboBoxClients.TabIndex = 4;
            // 
            // btn_settings
            // 
            this.btn_settings.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_settings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_settings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_settings.Location = new System.Drawing.Point(408, 106);
            this.btn_settings.Margin = new System.Windows.Forms.Padding(4);
            this.btn_settings.Name = "btn_settings";
            this.btn_settings.Size = new System.Drawing.Size(133, 51);
            this.btn_settings.TabIndex = 5;
            this.btn_settings.Text = "Settings";
            this.btn_settings.UseVisualStyleBackColor = false;
            // 
            // lbl_server_status
            // 
            this.lbl_server_status.AutoSize = true;
            this.lbl_server_status.BackColor = System.Drawing.Color.Transparent;
            this.lbl_server_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_server_status.Location = new System.Drawing.Point(581, 195);
            this.lbl_server_status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_server_status.Name = "lbl_server_status";
            this.lbl_server_status.Size = new System.Drawing.Size(136, 20);
            this.lbl_server_status.TabIndex = 6;
            this.lbl_server_status.Text = "Server Status: ";
            // 
            // lbl_clients
            // 
            this.lbl_clients.AutoSize = true;
            this.lbl_clients.BackColor = System.Drawing.Color.Transparent;
            this.lbl_clients.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_clients.Location = new System.Drawing.Point(581, 430);
            this.lbl_clients.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_clients.Name = "lbl_clients";
            this.lbl_clients.Size = new System.Drawing.Size(80, 20);
            this.lbl_clients.TabIndex = 7;
            this.lbl_clients.Text = "Clients: ";
            // 
            // lbl_server_ip
            // 
            this.lbl_server_ip.AutoSize = true;
            this.lbl_server_ip.BackColor = System.Drawing.Color.Transparent;
            this.lbl_server_ip.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_server_ip.Location = new System.Drawing.Point(581, 269);
            this.lbl_server_ip.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_server_ip.Name = "lbl_server_ip";
            this.lbl_server_ip.Size = new System.Drawing.Size(93, 20);
            this.lbl_server_ip.TabIndex = 8;
            this.lbl_server_ip.Text = "Server IP:";
            // 
            // lbl_server_port
            // 
            this.lbl_server_port.AutoSize = true;
            this.lbl_server_port.BackColor = System.Drawing.Color.Transparent;
            this.lbl_server_port.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_server_port.Location = new System.Drawing.Point(581, 349);
            this.lbl_server_port.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_server_port.Name = "lbl_server_port";
            this.lbl_server_port.Size = new System.Drawing.Size(111, 20);
            this.lbl_server_port.TabIndex = 9;
            this.lbl_server_port.Text = "Server Port:";
            // 
            // txt_message
            // 
            this.txt_message.Location = new System.Drawing.Point(299, 501);
            this.txt_message.Margin = new System.Windows.Forms.Padding(4);
            this.txt_message.Name = "txt_message";
            this.txt_message.Size = new System.Drawing.Size(242, 22);
            this.txt_message.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(50, 503);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Enter message:";
            // 
            // btn_server_sendmessage
            // 
            this.btn_server_sendmessage.BackColor = System.Drawing.Color.Gainsboro;
            this.btn_server_sendmessage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_server_sendmessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_server_sendmessage.Location = new System.Drawing.Point(585, 490);
            this.btn_server_sendmessage.Margin = new System.Windows.Forms.Padding(4);
            this.btn_server_sendmessage.Name = "btn_server_sendmessage";
            this.btn_server_sendmessage.Size = new System.Drawing.Size(188, 76);
            this.btn_server_sendmessage.TabIndex = 12;
            this.btn_server_sendmessage.Text = "Send Message";
            this.btn_server_sendmessage.UseVisualStyleBackColor = false;
            this.btn_server_sendmessage.Click += new System.EventHandler(this.btn_server_sendmessage_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 550);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Clients online:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Server_Build.Properties.Resources._360_F_294160181_pQRQN57WkigBOewq7BUMBbMtzkYtlFnQ;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(951, 626);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_server_sendmessage);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txt_message);
            this.Controls.Add(this.lbl_server_port);
            this.Controls.Add(this.lbl_server_ip);
            this.Controls.Add(this.lbl_clients);
            this.Controls.Add(this.lbl_server_status);
            this.Controls.Add(this.btn_settings);
            this.Controls.Add(this.comboBoxClients);
            this.Controls.Add(this.rch_text_log);
            this.Controls.Add(this.btn_stop_server);
            this.Controls.Add(this.btn_Start_Server);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Start_Server;
        private System.Windows.Forms.Button btn_stop_server;
        private System.Windows.Forms.RichTextBox rch_text_log;
        private System.Windows.Forms.ComboBox comboBoxClients;
        private System.Windows.Forms.Button btn_settings;
        private System.Windows.Forms.Label lbl_server_status;
        private System.Windows.Forms.Label lbl_clients;
        private System.Windows.Forms.Label lbl_server_ip;
        private System.Windows.Forms.Label lbl_server_port;
        private System.Windows.Forms.TextBox txt_message;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_server_sendmessage;
        private System.Windows.Forms.Label label2;
    }
}

